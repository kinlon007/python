for j in range(1,101):
	if (j % 7 == 0  or j %10 == 7 or j // 10 == 7):
		continue
	else:
		print(j)
